//Edit nyo lang ang payload then sa Url example m.facebook.com eencrypt nyo muna bago i-repalce
[
   {
	  "NAME":"TNT",
	  "Info":"IG PROMO",
	   "Payload":{ "Url":"CEF69FAA0F99FAADFABAFAABFAA6FAA9FAA9FAA9FD6FA0CFAAAFAAAFA0CFA08FA0AFAA8FA0AFA00FA0EFAAAFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
            "Back-Querry":false,
		  "Keep-Alive":true
	  }
  },
    {
	  "NAME":"GTM",
	  "Info":"GO SURF PROMO",
	   "Payload":{ "Url":"CEF69FAA0F99FAADFABAFAABFAA6FA09FD6FA0CFA08FAAAF98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
            "Back-Querry":false,
		  "Keep-Alive":true
	  }
  },
    {
	  "NAME":"SUN",
	  "Info":"TU PROMO",
	   "Payload":{ "Url":"AA9FA0AFA0EFAB0FA0EFAA0FD6FAACFAACFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
            "Back-Querry":false,
		  "Keep-Alive":true
	  }
  }
]
